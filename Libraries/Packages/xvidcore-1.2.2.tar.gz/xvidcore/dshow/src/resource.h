//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by xvid.ax.rc
//
#define VERSION_RES_MINOR_VER           0
#define VERSION_RES_BUILD               0
#define VER_DEBUG                       0
#define IDS_ABOUT                       1
#define VERSION_RES_MAJOR_VER           8
#define IDD_ABOUT                       102
#define IDB_LOGO                        103
#define IDC_BRIGHTNESS                  1002
#define IDC_DEBLOCK_UV                  1003
#define IDC_DEBLOCK_Y                   1004
#define IDC_FLIPVIDEO                   1005
#define IDC_COLORSPACE                  1006
#define IDC_RESET                       1007
#define IDC_FILMEFFECT                  1008
#define IDC_DERING                      1009
#define IDC_DERINGY                     1009
#define IDC_DIVX                        1010
#define IDC_COMPAT                      1011
#define IDC_MP4V                        1012
#define IDC_DX50                        1013
#define IDC_DERINGUV                    1014
#define IDC_USE_AR                      1015
#define VERSION_RES_LANGUAGE            0x409
#define VERSION_RES_CHARSET             1252
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

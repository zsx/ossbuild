#!/bin/sh
exec autoreconf -f -i -v
